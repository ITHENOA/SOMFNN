# Self-Adaptive-Fuzzy-Learning-System
The MATLAB code for the research paper titled "A Self-Adaptive Fuzzy Learning System for Streaming Data Prediction".
This work is described in:
===============================================================================================================================
Gu, X., Shen, Q. (2021). A Self-Adaptive Fuzzy Learning System for Streaming Data Prediction. Information Sciences, Accepted.
===============================================================================================================================
Please cite the paper above if this code helps. 
Programmed by Xiaowei Gu. For any queries about the code, please contact Dr. Xiaowei Gu: xig4@aber.ac.uk
Editable source code will be available soon
